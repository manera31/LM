import * as React from 'react';
import { Button, Container, Content, Header, Tab, Tabs, TabHeading, Icon, Text, Body, Title, Left, Right, Textarea, Form, CardItem,} from 'native-base';
import { Ionicons } from '@expo/vector-icons';


export default class descanso extends React.Component {
  render() {
    return (
      <React.Fragment>
      <Text style={{ marginTop: 70, fontSize: 50, textAlign: 'center'}}>Descanso</Text>
      </React.Fragment>
    ); 
  }
}